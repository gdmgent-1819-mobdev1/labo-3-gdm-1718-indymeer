
function createNode(element) {
    return document.createElement(element);
}

function append(parent, el) {
  return parent.appendChild(el);
}

// lege arrays om te storen

let people = new Array();
console.log(people);



let like_button = new Array();
console.log(like_button);

let dislike_button = new Array();
console.log(dislike_button);

var bad = document.getElementById("nope");
var good = document.getElementById("like");



// buttons
bad.addEventListener("click", function (event) {
  event.preventDefault();
  
  let array = JSON.parse(localStorage.getItem('test'));

 array = people[i]++;
 
  console.log(currentProfile.name);
    console.log(index);
    if(index>=9){
        index=0;
        fetchData();
    }else{
        index++;
    }

  if (people.allPeople) {
      like_button.push(people.allPeople)
  }


})


good.addEventListener("click", function (event) {
  event.preventDefault();

  if (people.allPeople) {
      dislike_button.push(people.allPeople)
  }

})



// create elements plus insert json


const ul = document.getElementById('main-window');

fetch('https://randomuser.me/api?results=10').then(response => {
  return response.json();
}).then(data => { 
 //call in objects from json 


  function create(){
    for(let i=0; i<10; i++){
    let authors = data.results[i];
    localStorage.setItem('test', JSON.stringify(authors));
   
   
  let allPeople = {
        name: authors.name.first + authors.name.last,
        picture: authors.picture.large,
        age: authors.dob.age 
      }
      people.push(allPeople);
      
      ul.innerHTML = "";
  let li = createNode('div');
   let  span = createNode('span');
      let info = document.createElement('div');
      let quote = createNode('div');
     
      info.className = "user-info";
      li.className = "user-image";
      span.className = "username";
      quote.className = "quote";
      

  li.style.background = 'url('+ authors.picture.large + ')';
  span.innerHTML = authors.name.first + authors.name.last;
  quote.innerHTML = "age" + " " + authors.dob.age;


  append(info, quote);
  append(li, span);
  append(ul, li);
  append(ul, info);
    } 
  }create();  



}).catch(function(error) {
  console.log(error.message);
})
;   
 

function element(){
  
}